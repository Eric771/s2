import os, requests, json, urllib.parse, traceback, random, os.path
from BEAPI import BEAPI

"""
FIXPRIMARY v1.1.170122
AUTHOR: UNYPASS

# USAGE
from fixprimary import *

# customHeader : chrome / desktopmac / desktopwin
bot1 = FIXPRIMARY("TOKEN_PRIMARY", customHeader="chrome")
client = LINE(bot1.authToken, appName=bot1.appName)
"""

api = BEAPI("NO_APIKEY")

def readJSON(filename):
    return json.loads(open(filename,"r").read())

def writeJSON(filename, data):
    open(filename, "w").write(json.dumps(data, indent=2))

def prints(text):
    print("[ FIXPRIMARY ] "+text)

def successPrint():
    prints("SUCCESS !!!")
    print("=============[ FINISH ]=============")

class FIXPRIMARY(object):
    def __init__(self, primary_token, execute=True, customHeader="chrome"):
        self.customHeader = customHeader
        self.primary_token = primary_token
        self.mid = primary_token.split(":")[0]
        self.foldername = "fixprimary_token"
        self.filename = f"{self.foldername}/{self.mid}.json"
        if execute:
            self.createDir()
            self.headers()
            self.execute()

    def execute(self):
        print("===========[ FIXPRIMARY ]===========")
        print("MID         : " + self.mid)
        print("HEADERS     : " + self.appName.replace("\t","\\t"))
        print("VERSION     : 1.1.170122")
        print("AUTHOR      : UNYPASS")
        print("LAST UPDATE : 17 January 2022")
        print("")

        if os.path.exists(self.filename):
            result = readJSON(self.filename)
            self.appName, self.authToken = result["appName"], result["authToken"]
            if self.fixLiff():
                successPrint()
            else:
                self.removeFile()
                self.fixingPrimary()
        else:
            self.fixingPrimary()
            successPrint()

    def fixingPrimary(self):
        try:
            prints("FIXING A PRIMARY....")
            result = api.linePrimary2Secondary(appName=self.appName, authToken=self.primary_token)["result"]
            self.authToken = result["token"]
            writeJSON(self.filename, {"authToken": self.authToken, "appName": self.appName})
        except Exception as e:
            raise Exception(str(e))

    def headers(self):
        app = {
            "desktopwin":"DESKTOPWIN\t6.5.0\tWindows\t10.0",
            "desktopmac":"DESKTOPMAC\t6.5.0\tMAC\t10.14.1",
            "chrome": "CHROMEOS\t2.4.5\tChrome_OS\t1"
        }
        if self.customHeader in app:
            self.appName = app[self.customHeader]
        else:
            raise Exception("# Invalid App #\nInput: chrome / desktopmac / desktopwin")

    def getMidlist(self):
        return [x.replace(".json","") for x in os.listdir(self.filename)]

    def createDir(self):
        if os.path.exists(self.foldername) == False:
            os.system("mkdir "+self.foldername)

    def removeFile(self):
        try:os.remove(self.filename)
        except:pass

    def fixLiff(self, ch_id="1602687308"):
        data = {'on': ['P', 'CM'], 'off': []}
        headers = {'X-Line-Access': self.authToken, 'X-Line-Application': self.appName, 'X-Line-ChannelId': ch_id, 'Content-Type': 'application/json'}
        r = requests.post("https://access.line.me/dialog/api/permissions", headers=headers, data=json.dumps(data)).text
        if "{}" in r:
            prints("AUTH TOKEN VALID !!!")
            return True
        else:
            prints("AUTH TOKEN INVALID !!!")
            return False