# -*- coding: utf-8 -*-
from linepy import *
from akad.ttypes import Message
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad.ttypes import ContentType as Type
from akad.ttypes import TalkException
from akad.ttypes import *
from famz.thrift.protocol import TCompactProtocol
from famz.thrift.transport import THttpClient
from famz.ttypes import LoginRequest
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
from gtts import gTTS
from threading import Thread
from io import StringIO
from multiprocessing import Pool
from googletrans import Translator
from urllib.parse import urlencode
from wikiapi import WikiApi
from tmp.MySplit import *
from zalgo import zalgoname
from random import randint
from shutil import copyfile
from youtube_dl import YoutubeDL
import LineService
import subprocess, youtube_dl, humanize, traceback
import subprocess as cmd
import time, random, sys, json, null, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback, livejson
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
import chatServer
#=======================================================
## FREE TOKEN FOR YOU :D ##
from fixprimary import * 
#t = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJqdGkiOiJhNjlmNmNjNS05MTQ5LTQ1YzgtODM1MS03YTM1ZTY1MzYxZmMiLCJhdWQiOiJMSU5FIiwiaWF0IjoxNjUzMzk4NjMyLCJleHAiOjE2NTQwMDM0MzIsInNjcCI6IkxJTkVfQ09SRSIsInJ0aWQiOiJjZGUyMzMxOC0zMGYxLTQ4ZjEtODZhYi05YzQ0N2RkYzQwZTgiLCJyZXhwIjoxODExMDc4NjMyLCJ2ZXIiOiIzLjEiLCJhaWQiOiJ1ZDMzMjgyNTk1N2QxNjRiYzg4MGRiOTMzYWViYzJjYmIiLCJsc2lkIjoiOGZmMzZlMmUtZGMxNy00OTUyLThiZDItYzIwNjliYmM1MzM0IiwiZGlkIjoiNTA3NmNiY2E5MDk0NDBhNGIwNGYzODM3MzhkZDU3NTAiLCJjdHlwZSI6IklPUyIsImNtb2RlIjoiUFJJTUFSWSIsImNpZCI6IjAwMDAwMDAwMDAifQ.DBLD16jZ1_zn1ehLcvKxCev-jqOxsgffv9XchmGNNV0"
#bot1 = FIXPRIMARY(t, customHeader="chrome")
#pub = LINE(bot1.authToken, appName=bot1.appName)

pub = LINE("ksamr880@gmail.com","Ssaa1122")
pubProfile = pub.getProfile()
khieSettings = pub.getSettings()
client = pub()
pubPoll = OEPoll(pub)
pubMID = pub.getProfile().mid
print ("login done pub Mid: " + pubMID)
#=====================================================
voice_clients = [pub]
#=======================
#===========================
settingsOpen = codecs.open("settings.json", "r", "utf-8")
UsersOpen = codecs.open("users.json", "r", "utf-8")
#=======================================================
maker = [
    "u9b9897fdd536e9886a4b7c28def482cf",
]
CMids = {"licon":{}}
#=======================================================
loop = asyncio.get_event_loop()
#=======================================================
botStart = time.time()
readAllbot = {"status":[]}
#=======================================================
#wait = json.load(waitOpen)
settings = json.load(settingsOpen)
Customers = json.load(UsersOpen)
#=======================================================
settings["myProfile"]["displayName"] = pubProfile.displayName
cont = pub.getContact(pubMID)
#=====================================================================
with open("settings.json", "r", encoding="utf_8_sig") as f:
    anu = json.loads(f.read())
    anu.update(settings)
    settings = anu
#=====================================================================
def restartBot():
    print ("[ INFO ] BOT RESETTED")
    backupData()
    python = sys.executable
    os.execl(python, python, *sys.argv)
def debug():
    get_profile_time_start = time.time()
    get_profile = pub.getProfile()
    get_profile_time = time.time() - get_profile_time_start
    get_group_time_start = time.time()
    get_group = pub.getGroupIdsJoined()
    get_group_time = time.time() - get_group_time_start
    get_contact_time_start = time.time()
    get_contact = pub.getContact(get_profile.mid)
    get_contact_time = time.time() - get_contact_time_start
    elapsed_time = time.time() - get_profile_time_start
    return " 「 Debug 」\n - Send Message\n   %.5f\n - Get Profile\n   %.5f\n - Get Contact\n   %.5f\n - Get Group\n   %.5f" % (elapsed_time,get_profile_time,get_contact_time,get_group_time)
def logError(text):
    pub.log("ERROR 404 !\n" + str(text))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = hasil + ", " + inihari.strftime('%d') + " - " + bln + " - " + inihari.strftime('%Y') + " | " + inihari.strftime('%H:%M:%S')
    with open("errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))
def backupData():
    try:
        backup = settings
        f = codecs.open('settings.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        #backup = wait
        #f = codecs.open('wait.json','w','utf-8')
        #json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = Customers
        f = codecs.open('users.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False
#=====================================================================
def sendMention(to, mid, firstmessage='', lastmessage=''):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        try:
            pub.sendMessage(to, text, {'MSG_SENDER_NAME': pub.getContact(mid).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + pub.getContact(mid).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        except Exception as e:
            pub.sendMessage(to, text, {'MSG_SENDER_NAME': pub.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").displayName,'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + pub.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        print(error)
def mentions(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@KhieGans  "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    pub.sendMessage(to, textx, {'AGENT_NAME':'LINE OFFICIAL', 'AGENT_LINK': 'line://ti/p/~{}'.format(pub.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + pub.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
#=====================================================================
def command(text):
    pesan = text.lower()
    if settings["setKey"] == True:
        if pesan.startswith(settings["keyCommand"]):
            cmd = pesan.replace(settings["keyCommand"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd
def removeCmd(cmd, text):
    key = settings["keyCommand"]
    if settings["setKey"] == False: key = ''
    rmv = len(key + cmd) + 1
    return text[rmv:]
#=====================================================================
def Lcontact(x):
    num = 0
    ngen = []
    tot = 0
    tot += len(CMids["licon"])
    tot -= int(x)
    for a in CMids["licon"]:
        num +=1
        if num == tot:
            ngen.append(a)
            num -=1
    return ngen
#=====================================================================
# Template Functions
lifflist = ["1602687308-GXq4Vvk9", "1656199698-gYJaDxdJ","1656613356-bJm9z8x6","1656086034-5De9BMoq", "1656162526-ZKWnYxzv"]

def allowLiff(ch_id):
    # Copyright by https://github.com/RynKings
    data = {'on': ['P', 'CM'], 'off': []}
    headers = {
        'X-Line-Access': pub.authToken,
        'X-Line-Application': pub.appName,
        'X-Line-ChannelId': ch_id,
        'Content-Type': 'application/json'
    }
    r = requests.post("https://access.line.me/dialog/api/permissions", headers=headers, data=json.dumps(data))
    return r.json()

def sendTemplate(group, data):
    random.shuffle(lifflist)
    for liffs in lifflist:
        try:
            xyz = LiffChatContext(to)
            xyzz = LiffContext(chat=xyz)
            view = LiffViewRequest(liffs, xyzz)
            try:token = pub.liff.issueLiffView(view).accessToken
            except Exception as e:
                if "consent" in str(e).lower():
                    allowLiff(liffs.split("-")[0])
                    token = pub.liff.issueLiffView(view).accessToken
                else:pub.sendMessage(to,str(e));break

            url = 'https://api.line.me/message/v3/share'
            headers = {
                'Authorization': 'Bearer %s' % token,
                'Accept' : 'application/json, text/plain, */*',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 9; Redmi Note 6 Pro Build/PKQ1.180904.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/94.0.4606.71 Mobile Safari/537.36 Line/11.9.0',
                'Accept-Encoding': 'gzip, deflate',
                'content-Type': 'application/json',
                'X-Requested-With': 'jp.naver.line.android'
            }
            data = {"messages":[data]}

            r = requests.post(url, headers=headers, data=json.dumps(data))
            #print(r.text)
            time.sleep(random.randint(700, 1000) / 1000)
            if "blocked" not in r.text.lower():
                #print(liffs + " : " + r.text)
                break

        except Exception as e:
            traceback.print_tb(e.__traceback__)
            logError(e)
            break

#=====================================================================
yt_dl_opts = {'format': 'bestaudio/best'}
ytdl = youtube_dl.YoutubeDL(yt_dl_opts)

ffmpeg_options = {'options': "-vn"}


# This event happens when the bot gets run
@client.event
async def on_ready():
    print(f"Bot logged in as {client.user}")


# This event happens when a message gets sent
@client.event
async def on_message(msg):
    if msg.content.startswith("?play"):

        try:
            voice_client = await msg.author.GroupCall(to,)
            voice_clients[voice_client.guild.id] = voice_client
        except:
            print("error")

        try:
            url = msg.content.split()[1]

            loop = asyncio.get_event_loop()
            data = await loop.run_in_executor(None, lambda: ytdl.extract_info(url, download=False))

            song = data['url']
            player = pub.FFmpegPCMAudio(song, **ffmpeg_options)

            voice_clients[msg.guild.id].play(player)

        except Exception as err:
            print(err)


    if msg.content.startswith("?pause"):
        try:
            voice_clients[msg.guild.id].pause()
        except Exception as err:
            print(err)

    # This resumes the current song playing if it's been paused
    if msg.content.startswith("?resume"):
        try:
            voice_clients[msg.guild.id].resume()
        except Exception as err:
            print(err)

    # This stops the current playing song
    if msg.content.startswith("?stop"):
        try:
            voice_clients[msg.guild.id].stop()
            await voice_clients[msg.guild.id].disconnect()
        except Exception as err:
            print(err)
#=============================================================
# Templates 亗『 ꜱʜᴀᴀɴ 』亗
Customer = {
    "makerName": "Eric",
    "makerTextLogo": "Eric",
    "makerMark": "Eric",
    "makerFlag": "Eric",
    "makerLineid" :"https://line.me/ti/p/~j71.a",
    "makerMid" : "https://line://nv/profilePopup/mid=u9b9897fdd536e9886a4b7c28def482cf",
    "userFlag" : "Eric",
}
Colors = {
    "LogoBack": "#000000",       # Colors["LogoBack"],
    "LogoFont": "#5C493F",       # Colors["LogoFont"],
    "Template": "#708090",       # Colors["Template"],
    "Background": "#006666",     # Colors["Background"] + Colors["Transparency"],
    "Border": "#CCFFCC",         # Colors["Border"],
    "Liner": "#00B100",          # Colors["Liner"],
    "Heading": "#FFCCAA",        # Colors["Heading"],
    "Font": "#CCFFCC",           # Colors["Font"],
    "Transparency": "CC"         # Colors["Transparency"],
}
def ClientMenuWithHeading(to, heading, list):
    true = True
    false = False
    text = heading+"\n"+list
    contact = pub.getContact(pubMID)
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "micro",
            "body": {
                "type": "box",
                "layout": "vertical",
                "contents": [
                    {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                            {
                                "type": "text",
                                "text": "line",
                                "color": Colors["Border"]
                            }
                        ],
                        "position": "relative",
                        "width": "135px",
                        "backgroundColor": Colors["Border"],
                        "height": "1.5px"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "spacer",
                                "size": "sm"
                            },
                            {
                                "type": "text",
                                "text": heading,
                                "color": Colors["Font"],
                                "weight": "bold",
                                "size": "sm",
                                "align": "center"
                            },
                            {
                                "type": "spacer",
                                "size": "sm"
                            }
                        ],
                        "width": "135px"
                    },
                    {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                            {
                                "type": "text",
                                "text": "line",
                                "color": Colors["Border"]
                            }
                        ],
                        "position": "relative",
                        "width": "135px",
                        "backgroundColor": Colors["Border"],
                        "height": "1.5px"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "spacer",
                                "size": "xxl"
                            },
                            {
                                "type": "text",
                                "text": list,
                                "color": Colors["Font"],
                                "wrap": true,
                                "size": "xs"
                            }
                        ]
                    }
                ],
                "cornerRadius": "10px",
                "backgroundColor": Colors["Background"],
                "borderWidth": "1.5px",
                "borderColor": Colors["Border"]
            }
        }
            }
    if settings["fancy"] == True:
            sendTemplate(to, data)
    else:
        pub.sendMessage(to, " "+text)
def ClientMessage(to, message):
    true = True
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "kilo",
            "body": {
                "type": "box",
                "layout": "vertical",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": message,
                                "color": Colors["Font"],
                                "wrap": true,
                                "size": "sm"
                            }
                        ]
                    }
                ],
                "cornerRadius": "10px",
                "backgroundColor": Colors["Background"],
                "borderWidth": "2px",
                "borderColor": Colors["Border"]
            }
        }
                   }
    if settings["fancy"] == True:
        sendTemplate(to, data)
    else:
        pub.sendMessage(to, message)
def ClientMessageFlag(to, message):
    true = True
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "kilo",
            "body": {
                "type": "box",
                "layout": "vertical",
                "contents": [
                    {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                            {
                                "type": "text",
                                "text": message,
                                "size": "sm",
                                "wrap": true,
                                "align": "center",
                                "color": Colors["Font"],
                                "action": {
                                    "type": "uri",
                                    "uri": Customer["makerLineid"]
                                }
                            }
                        ],
                        "margin": "xs",
                        "spacing": "xs",
                        "backgroundColor": Colors["Background"]
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": Customer["userFlag"],
                                "align": "center",
                                "color": Colors["Font"],
                                "size": "xs",
                                "action": {
                                    "type": "uri",
                                    "uri": Customer["makerLineid"]
                                }
                            }
                        ],
                        "paddingAll": "0px",
                        "backgroundColor": Colors["Template"]
                    }
                ],
                "paddingAll": "0px",
                "borderWidth": "1.5px",
                "borderColor": Colors["Font"],
                "cornerRadius": "10px",
                "spacing": "xs"
            },
            "styles": {
                "body": {
                    "backgroundColor": Colors["Background"]
                }
            }
        }
                   }
    if settings["fancy"] == True:
        sendTemplate(to, data)
    else:
        pub.sendMessage(to, message)
def TSider1(to, memberPP, memberName, Message):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "body": {
                "type": "box",
                "layout": "vertical",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "horizontal",
                                        "contents": [
                                            {
                                                "type": "image",
                                                "url": memberPP,
                                                "size": "full",
                                                "aspectMode": "cover",
                                                "aspectRatio": "2:3"
                                            }
                                        ],
                                        "width": "56px",
                                        "height": "61.5px",
                                        "borderWidth": "1.5px",
                                        "borderColor": Colors["Font"],
                                        "cornerRadius": "xl",
                                        "action": {
                                            "type": "uri",
                                            "uri": Customer["makerLineid"]
                                        }
                                    },
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                            {
                                                "type": "text",
                                                "text": memberName,
                                                "weight": "bold",
                                                "size": "lg",
                                                "color": Colors["Font"],
                                                "align": "center"
                                            },
                                            {
                                                "type": "separator",
                                                "color": Colors["Font"],
                                                "margin": "sm"
                                            },
                                            {
                                                "type": "text",
                                                "text": Message,
                                                "size": "md",
                                                "margin": "md",
                                                "color": Colors["Font"],
                                                "align": "center",
                                                "wrap": true
                                            }
                                        ],
                                        "margin": "lg"
                                    }
                                ]
                            }
                        ],
                        "paddingAll": "5px",
                        "backgroundColor": Colors["Background"],
                        "borderWidth": "1.5px",
                        "borderColor": Colors["Font"],
                        "cornerRadius": "xl"
                    }
                ],
                "paddingAll": "0px"
            }
        }
                   }
    sendTemplate(to, data)
def groupscast(to, message):
    true = True
    false = False
    data = {"type": "flex", "altText": "{}".format(Customer["makerName"]), "contents":
        {
            "type": "bubble",
            "size": "kilo",
            "body": {
                "borderWidth": "2px",
                "borderColor": Colors["Border"],
                "cornerRadius": "10px",
                "contents": [
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": Colors["Border"]
                            }
                        ],
                        "backgroundColor": Colors["Border"],
                        "width": "230px",
                        "height": "2px"
                    },
                    {
                        "contents": [
                            {
                                "text": "GROUPCAST",
                                "size": "lg",
                                "align": "center",
                                "color": Colors["Font"],
                                "wrap": true,
                                "weight": "bold",
                                "type": "text"
                            }
                        ],
                        "type": "box",
                        "spacing": "sm",
                        "layout": "vertical",
                        "width": "230px"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": "liner",
                                "color": Colors["Border"]
                            }
                        ],
                        "backgroundColor": Colors["Border"],
                        "width": "230px",
                        "height": "2px"
                    },
                    {
                        "contents": [
                            {
                                "type": "spacer",
                                "size": "xxl"
                            },
                            {
                                "contents": [
                                    {
                                        "text": message,
                                        "size": "md",
                                        "margin": "none",
                                        "color": Colors["Font"],
                                        "wrap": true,
                                        "weight": "regular",
                                        "type": "text",
                                        "align": "center"
                                    }
                                ],
                                "type": "box",
                                "layout": "baseline"
                            }
                        ],
                        "type": "box",
                        "layout": "vertical"
                    }
                ],
                "type": "box",
                "spacing": "md",
                "layout": "vertical"
            },
            "styles": {
                "body": {
                    "backgroundColor": Colors["Background"]
                },
                "footer": {
                    "backgroundColor": Colors["Background"]
                }
            }
        }
            }
    if settings["fancy"] == True:
        sendTemplate(to, data)
    else:
        pub.sendMessage(to, "𝗚𝗿𝗼𝘂𝗽𝗰𝗮𝘀𝘁\n\n" + message)
#=====================================================================
#Helpmenu
def txmenuMaker(prefixx):
    return """⌬ {pref}help maker    
⌬ {pref}help buyers
⌬ {pref}help users
⌬ {pref}help public
𝗛𝗲𝗹𝗽 𝗠𝗮𝗸𝗲𝗿
⌬ {pref}limit buyers:
⌬ {pref}buyer
⌬ {pref}delbuyer
⌬ {pref}limit users:
⌬ {pref}update all
⌬ debug
𝗛𝗲𝗹𝗽 𝗕𝘂𝘆𝗲𝗿𝘀
⌬ ping
⌬ prefix
⌬ clear prefix
⌬ {pref}help
⌬ {pref}settings
⌬ {pref}upname
⌬ {pref}upbio
⌬ {pref}upimage
⌬ {pref}user
⌬ {pref}addme
⌬ {pref}users
⌬ {pref}expel
⌬ {pref}groups
⌬ {pref}groupcast [text]
⌬ {pref}members
⌬ {pref}cmembers
⌬ {pref}pendings
⌬ {pref}cpendings
⌬ {pref}ourl
⌬ {pref}curl
⌬ {pref}leave
⌬ {pref}bye
⌬ {pref}reboot
𝗛𝗲𝗹𝗽 𝗨𝘀𝗲𝗿𝘀
⌬ {pref}liff
⌬ {pref}login
⌬ {pref}logout
⌬ {pref}restart
𝗛𝗲𝗹𝗽 𝗣𝘂𝗯𝗹𝗶𝗰
⌬ {pref}mid
⌬ {pref}cmid
⌬ {pref}tagall
⌬ {pref}lurk on|off
⌬ {pref}lurkmsg [text]
⌬ {pref}sider on|off
⌬ {pref}sidermsg [text]""".format(pref=prefixx)
def txmenuBuyer(prefixx):
    return """⌬ ping
⌬ prefix
⌬ clear prefix
⌬ {pref}help
⌬ {pref}settings
⌬ {pref}upname
⌬ {pref}upbio
⌬ {pref}upimage
⌬ {pref}user
⌬ {pref}addme
⌬ {pref}users
⌬ {pref}expel
⌬ {pref}groups
⌬ {pref}groupcast [text]
⌬ {pref}members
⌬ {pref}cmembers
⌬ {pref}pendings
⌬ {pref}cpendings
⌬ {pref}ourl
⌬ {pref}curl
⌬ {pref}leave
⌬ {pref}bye
⌬ {pref}reboot
⌬ {pref}mid
⌬ {pref}cmid
⌬ {pref}tagall
⌬ {pref}lurk on|off
⌬ {pref}lurkmsg [text]
⌬ {pref}sider on|off
⌬ {pref}sidermsg [text]""".format(pref=prefixx)
def txmenuUser(prefixx):
    return """⌬ ping
⌬ {pref}help
⌬ {pref}liff
⌬ {pref}login
⌬ {pref}logout
⌬ {pref}restart
⌬ {pref}mid
⌬ {pref}cmid
⌬ {pref}tagall
⌬ {pref}lurk on|off
⌬ {pref}lurkmsg [text]
⌬ {pref}sider on|off
⌬ {pref}sidermsg [text]""".format(pref=prefixx)
def txmenuPublic(prefixx):
    return """⌬ {pref}mid
⌬ {pref}cmid
⌬ {pref}tagall
⌬ {pref}lurk on|off
⌬ {pref}lurkmsg [text]
⌬ {pref}sider on|off
⌬ {pref}sidermsg [text]""".format(pref=prefixx)
def txmenuThemes(prefixx):
    return """⌬ {pref}theme default
⌬ {pref}theme red
⌬ {pref}theme pink
⌬ {pref}theme blue
⌬ {pref}theme cyan
⌬ {pref}theme black
⌬ {pref}theme white
⌬ {pref}theme yellow
⌬ {pref}theme purple
⌬ {pref}theme golden
⌬ {pref}theme green
⌬ {pref}setid: [text]
⌬ {pref}clrfont: [text]
⌬ {pref}clrbg: [text]
⌬ {pref}clrtemp: [text]
⌬ {pref}set flag: [text]
⌬ {pref}color selection""".format(pref=prefixx)
def txmenuSettings(prefixx):
    return """⌬ {pref}autoread on|off
⌬ {pref}autojoin on|off
⌬ {pref}join on|off
⌬ {pref}joinmsg: [text]
⌬ {pref}welcome on|off
⌬ {pref}welcomemsg: [text]
⌬ {pref}leave on|off
⌬ {pref}leavemsg: [text]
⌬ {pref}bye on|off
⌬ {pref}byemsg: [text]
⌬ {pref}themes""".format(pref=prefixx)
#=====================================================================
async def helprBot(op):
    try:
        if settings["restartPoint"] != None:
            ClientMessage(settings["restartPoint"], 'Activated')
            settings["restartPoint"] = None
        if op.type == 0:
            return
        #print(str(op.type) + "\n" + str(op) + "\n\n")
        if op.type == 5:
            print("add")
            #ClientMessage(to, "add contact")
            print("[ 5 ] NOTIFIED AUTO ADD CONTACT")
            if settings["autoAdd"] == True:
                pub.findAndAddContactsByMid(op.param1)
                ClientMessageFlag(op.param1, settings["addMessageText"])
        if op.type == 124:
            print("invite")
            if pubMID in op.param3:
                pub.acceptGroupInvitation(op.param1)
                if settings["joinMessage"] == True:
                    pubName = "{}".format(str(pub.getContact(pubMID).displayName))
                    pubPP = "https://obs.line-scdn.net/{}".format(pub.getContact(pubMID).pictureStatus)
                    pubCV = "https://obs.line-scdn.net/{}".format(pub.getProfileCoverURL(pubMID))
                    inviterName = "{}".format(str(pub.getContact(op.param2).displayName))
                    inviterPP = "https://obs.line-scdn.net/{}".format(pub.getContact(op.param2).pictureStatus)
                    inviterCV = "https://obs.line-scdn.net/{}".format(pub.getProfileCoverURL(op.param2))
                    Message = settings["joinMessageText"]
                    ClientMessage(op.param1, settings["joinMessageText"]+" "+inviterName)
        if op.type == 130:
            print("join")
            if settings["welcomeMessage"] == True:
                Message = settings["welcomeMessageText"]
                pubName = "{}".format(str(pub.getContact(pubMID).displayName))
                pubPP = "https://obs.line-scdn.net/{}".format(pub.getContact(pubMID).pictureStatus)
                pubCV = "https://obs.line-scdn.net/{}".format(pub.getContact(pubMID).pictureStatus)
                memmberName = "{}".format(str(pub.getContact(op.param2).displayName))
                memmberPP = "https://obs.line-scdn.net/{}".format(pub.getContact(op.param2).pictureStatus)
                memmberCV = "https://obs.line-scdn.net/{}".format(pub.getProfileCoverURL(op.param2))
                ClientMessage(op.param1, settings["welcomeMessageText"]+" "+memmberName)
                time.sleep(2)
        if op.type == 133:
            print("kick")
            #ClientMessage(to, "kick from group")
        if op.type in [22,24]:
            print("mc")
            pub.leaveRoom(op.param1)
        if op.type == 126:
            print("cancel")
            #ClientMessage(to, "cancel from group")
        if op.type == 61:
            print ("leave")
            if settings["leaveMessage"] == True:
                pubName = "{}".format(str(pub.getContact(pubMID).displayName))
                pubPP = "https://obs.line-scdn.net/{}".format(pub.getContact(pubMID).pictureStatus)
                pubCV = "https://obs.line-scdn.net/{}".format(pub.getContact(pubMID).pictureStatus)
                memmberName = "{}".format(str(pub.getContact(op.param2).displayName))
                memmberPP = "https://obs.line-scdn.net/{}".format(pub.getContact(op.param2).pictureStatus)
                memmberCV = "https://obs.line-scdn.net/{}".format(pub.getProfileCoverURL(op.param2))
                Message = settings["leaveMessageText"]
                ClientMessage(op.param1, settings["leaveMessageText"]+" "+memmberName)
                time.sleep(2)
#=====================================================================
        if op.type == 26:
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 2:
                    if msg.contentType == 13:
                        if msg._from in maker or msg._from in Customers['Buyers']:
                            CMids["licon"][msg.contentMetadata["mid"]] = True
                if msg.toType == 0 and sender != pubMID: to = sender
                else: to = receiver
                if msg.contentType in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]:
                    if msg.toType == 0:
                        if settings["autoRead"] == True:
                            pub.sendChatChecked(to, msg_id)
                    if msg.toType == 2:
                        if settings["autoRead"] == True:
                            pub.sendChatChecked(to, msg_id)
                if msg.contentType == 0:
#==========================================pub.sendMessage
# MAKER ONLY COMMANDS
#==========================================
                    if cmd == Customers["Prefix"] + "help":
                        if sender not in maker and sender not in Customers["Buyers"] and sender not in Customers["myService"]:
                            ClientMenuWithHeading(to, "𝗛𝗲𝗹𝗽 𝗠𝗲𝗻𝘂", txmenuPublic(Customers["Prefix"]))
                    if cmd == "mymid":
                        pub.sendMessage(msg.to, msg._from)
                    if cmd.startswith(Customers["Prefix"] + "mid "):
                        proses = text.split(" ")
                        tx = text.replace(proses[0] + " ", "")
                        num = text.replace(proses[0] + " lcon", "")
                        if "lcon" == proses[1] or "lcon" + num == proses[1]:
                            if "" == num:
                                num = "1"
                            l = int(num)
                            l -= 1
                            hasil = Lcontact(l)
                            num = []
                            for a in hasil:
                                pub.sendMessage(to, "{}\n\n{}".format(pub.getContact(a).displayName, a))
                        else:
                            key = eval(msg.contentMetadata["MENTION"])
                            if key == None:
                                return
                            else:
                                key["MENTIONEES"][0]["M"]
                                targets = []
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for a in targets:
                                    pub.sendMessage(to, "{}\n\n{}".format(pub.getContact(a).displayName, a))
                    if cmd.startswith(Customers["Prefix"] + "cmid "):
                        sep = text.split(" ")
                        search = text.replace(sep[0] + " ", "")
                        pub.sendContact(to, search)
                    if cmd == Customers["Prefix"] + "tagall":
                        group = pub.getGroup(to);
                        nama = [contact.mid for contact in group.members];
                        nama.remove(pub.getProfile().mid)
                        pub.datamention(to, 'Mention', nama)
                    if cmd == Customers["Prefix"] + "lurk":
                        if receiver not in settings["lurkRoom"]:
                            settings["lurkRoom"][receiver] = []
                            ClientMessageFlag(msg.to, "Lurking on.")
                        else:
                            del settings["lurkRoom"][receiver]
                            ClientMessageFlag(msg.to, "Lurking off.")
                    if cmd == Customers["Prefix"] + "lurk on":
                        if receiver in settings["lurkRoom"]:
                            ClientMessageFlag(msg.to, "Lurking already on.")
                        else:
                            settings["lurkRoom"][receiver] = []
                            ClientMessageFlag(msg.to, "Lurking on.")
                    if cmd == Customers["Prefix"] + "lurk off":
                        if receiver in settings["lurkRoom"]:
                            del settings["lurkRoom"][receiver]
                            ClientMessageFlag(msg.to, "Lurking off.")
                        else:
                            ClientMessageFlag(msg.to, "Lurking already off.")
                    if cmd.startswith(Customers["Prefix"] + "lurkmsg "):
                        text_ = removeCmd("lurkmsg", text)
                        try:
                            settings["lurkMessage"] = text_
                            ClientMessageFlag(msg.to, "Lurk Message changed to:\n" + text_)
                        except:
                            ClientMessageFlag(msg.to, "Failed to replace lurk message.")
                    if cmd == Customers["Prefix"] + "sider":
                        if receiver not in settings["siderRoom"]:
                            settings["siderRoom"][receiver] = []
                            ClientMessageFlag(msg.to, "Sider on.")
                        else:
                            del settings["siderRoom"][receiver]
                            ClientMessageFlag(msg.to, "Sider off.")
                    if cmd.startswith(Customers["Prefix"] + "sider on"):
                        if receiver in settings["siderRoom"]:
                            ClientMessageFlag(msg.to, "Sider already on.")
                        else:
                            settings["siderRoom"][receiver] = []
                            ClientMessageFlag(msg.to, "Sider on.")
                    if cmd.startswith(Customers["Prefix"] + "sider off"):
                        if receiver in settings["siderRoom"]:
                            del settings["siderRoom"][receiver]
                            ClientMessageFlag(msg.to, "Sider off.")
                        else:
                            ClientMessageFlag(msg.to, "Sider already off.")
                    if cmd.startswith(Customers["Prefix"] + "sidermsg "):
                        text_ = removeCmd("sidermsg", text)
                        try:
                            settings["siderMessage"] = text_
                            ClientMessageFlag(msg.to, "Sider Message changed to:\n" + text_)
                        except:
                            ClientMessageFlag(msg.to, "Failed to replace sider message.")
                    if sender in maker:
                        if cmd == Customers["Prefix"] + "help maker":
                            ClientMenuWithHeading(to, "𝗛𝗲𝗹𝗽 𝗠𝗲𝗻𝘂", txmenuMaker(Customers["Prefix"]))
                        if cmd == Customers["Prefix"] + "here":
                            pub.generateReplyMessage(msg.id)
                            pub.sendReplyMessage(msg.id, to,"I am here")
                        if cmd.startswith(Customers["Prefix"] + "limit buyers:"):
                            spl = removeCmd(",limit buyers:", text)
                            Customers["limBuyers"] = int(spl)
                            ClientMessage(to, "Buyers are Limited to: {}".format(Customers["limBuyers"]))
                        if cmd.startswith(Customers["Prefix"] + "buyer "):
                            if len(Customers["Buyers"]) < Customers["limBuyers"]:
                                proses = text.split(" ")
                                tx = text.replace(proses[0] + " ", "")
                                num = text.replace(proses[0] + " lcon", "")
                                if "lcon" == proses[1] or "lcon" + num == proses[1]:
                                    if "" == num:
                                        num = "1"
                                    l = int(num)
                                    l -= 1
                                    hasil = Lcontact(l)
                                    num = 0
                                    for a in hasil:
                                        if a not in Customers["Buyers"]:
                                            Customers["Buyers"].append(a)
                                            num += 1
                                    ClientMessage(to, "Promoted to buyer: {}".format(num))
                                else:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    if key == None:
                                        return
                                    else:
                                        key["MENTIONEES"][0]["M"]
                                        targets = []
                                        for x in key["MENTIONEES"]:
                                            targets.append(x["M"])
                                        num = 0
                                        for a in targets:
                                            if a not in Customers["Buyers"]:
                                                Customers["Buyers"].append(a)
                                                num += 1
                                        ClientMessage(to, "Promoted: {}".format(num))
                            else:
                                ClientMessage(to, "Maximum number of Buyers: {}".format(Customers["limBuyers"]))
                        if cmd.startswith(Customers["Prefix"] + "delbuyer "):
                            proses = text.split(" ")
                            tx = text.replace(proses[0] + " ","")
                            num = text.replace(proses[0] + " lcon","")
                            if "lcon"== proses[1] or "lcon"+num == proses[1]:
                                if "" == num:
                                    num = "1"
                                l = int(num)
                                l -=1
                                hasil = Lcontact(l)
                                num = 0
                                for a in hasil:
                                    if a in Customers["Buyers"]:
                                        Customers["Buyers"].remove(a)
                                        Customers['listLogin'].remove(a)
                                        os.system("screen -S {} -X quit".format(str(a)))
                                        os.system('rm -rf {}'.format(str(a)))
                                        num += 1
                                        ClientMessage(to, "Expelled Buyer: {}".format(num))
                                    else:
                                        if a not in Customers["Buyers"]:
                                            num += 1
                                            ClientMessage(to, "Skipped: {}".format(num))
                            else:
                                key = eval(msg.contentMetadata["MENTION"])
                                if key == None:return
                                else:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key["MENTIONEES"][0]["M"]
                                    targets = []
                                    for x in key["MENTIONEES"]:
                                        targets.append(x["M"])
                                        num = 0
                                        for a in targets:
                                            if a in Customers["Buyers"]:
                                                Customers["Buyers"].remove(a)
                                                num += 1
                                                ClientMessage(to, "Expelled Buyer: {}".format(num))
                                            else:
                                                if a not in Customers["Buyers"]:
                                                    num += 1
                                                    ClientMessage(to, "Skipped: {}".format(num))
                        if cmd == Customers["Prefix"] + "buyers":
                            if Customers["myService"] == []:
                                ClientMessage(to, "Buyers List is Empty!")
                            else:
                                text = "𝗕𝗨𝗬𝗘𝗥𝗦\n\n"
                                num = 0
                                for user in Customers["Buyers"]:
                                    try:
                                        num += 1
                                        text += str(num) + " {}\n".format(pub.getContact(user).displayName)
                                    except:
                                        Customers["Buyers"].remove(user)
                                        num -= 1
                                text += "\nTOTAL: {} buyers".format(str(len(Customers["Buyers"])))
                                ClientMessage(to, text)
                        if cmd.startswith(Customers["Prefix"] + "limit users:"):
                            spl =  removeCmd("limit users:", text)
                            Customers["limService"] = int(spl)
                            ClientMessage(to, "Users are Limited to: {}".format(Customers["limService"]))
                        if cmd == Customers["Prefix"] + "update all":
                            if Customers["myService"] != {}:
                                dataUs = []
                                failed_user = []
                                ClientMessage(to,"Please wait ⌛...")
                                for cust in Customers["myService"]:
                                    try:
                                        with open("{}/token1.txt".format(cust),"r") as z:
                                            token = z.read()
                                        os.system('rm -r {}\n'.format(str(cust)))
                                        time.sleep(2)
                                        os.system('cp -r sbtemp {}'.format(cust))
                                        dataUs.append(cust)
                                        time.sleep(1)
                                        os.system('cd {} && echo -n "{}" > token1.txt'.format(cust, token))
                                        time.sleep(1)
                                        os.system("screen -S {} -X quit".format(cust))
                                        os.system('screen -dmS {}'.format(cust))
                                        os.system('screen -r {} -X stuff "cd {} && python3 login.py \n"'.format(cust, cust))
                                    except:
                                        if cust in dataUs:
                                            dataUs.remove(cust)
                                            os.system('rm -r {}\n'.format(str(cust)))
                                            failed_user.append(cust)
                                pub.datamention(to, "Updating {} users ...".format(len(dataUs)), dataUs)
                                time.sleep(10)
                        if cmd == Customers["Prefix"] + "contact buyers":
                            if Customers["myService"] == []:
                                ClientMessage(to, "Buyers List is Empty!")
                            else:
                                for a in Customers["Buyers"]:
                                    pub.sendContact(to, a)
#==========================================
# BUYER AND MAKER COMMANDS
#==========================================
                    if sender in maker or sender in Customers["Buyers"]:
                        if cmd.startswith(Customers["Prefix"] + "expel "):
                            proses = text.split(" ")
                            tx = text.replace(proses[0] + " ","")
                            num = text.replace(proses[0] + " lcon","")
                            if "lcon"== proses[1] or "lcon"+num == proses[1]:
                                if "" == num:
                                    num = "1"
                                l = int(num)
                                l -=1
                                hasil = Lcontact(l)
                                num = 0
                                for a in hasil:
                                    if a in Customers["myService"]:
                                        Customers["myService"].remove(a)
                                        Customers['listLogin'].remove(a)
                                        os.system("screen -S {} -X quit".format(str(a)))
                                        os.system('rm -rf {}'.format(str(a)))
                                        num += 1
                                        ClientMessage(to, "Expelled User: {}".format(num))
                                    else:
                                        if a not in Customers["myService"]:
                                            num += 1
                                            ClientMessage(to, "Skipped: {}".format(num))
                            else:
                                key = eval(msg.contentMetadata["MENTION"])
                                if key == None:return
                                else:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key["MENTIONEES"][0]["M"]
                                    targets = []
                                    for x in key["MENTIONEES"]:
                                        targets.append(x["M"])
                                        num = 0
                                        for a in targets:
                                            if a in Customers["myService"]:
                                                Customers["myService"].remove(a)
                                                Customers['listLogin'].remove(a)
                                                os.system("screen -S {} -X quit".format(str(a)))
                                                os.system('rm -rf {}'.format(str(a)))
                                                num += 1
                                                ClientMessage(to, "Expelled User: {}".format(num))
                                            else:
                                                if a not in Customers["myService"]:
                                                    num += 1
                                                    ClientMessage(to, "Skipped: {}".format(num))
                        if cmd == Customers["Prefix"] + "help buyers":
                            ClientMenuWithHeading(to, "𝗛𝗲𝗹𝗽 𝗠𝗲𝗻𝘂", txmenuBuyer(Customers["Prefix"]))
                        if cmd == Customers["Prefix"] + "help users":
                            ClientMenuWithHeading(to, "𝗛𝗲𝗹𝗽 𝗠𝗲𝗻𝘂", txmenuUser(Customers["Prefix"]))
                        if cmd == Customers["Prefix"] + "help public":
                            ClientMenuWithHeading(to, "𝗛𝗲𝗹𝗽 𝗠𝗲𝗻𝘂", txmenuPublic(Customers["Prefix"]))
                        if cmd == Customers["Prefix"] + "settings":
                            ClientMenuWithHeading(to, "𝗦𝗲𝘁𝘁𝗶𝗻𝗴𝘀", txmenuSettings(Customers["Prefix"]))
                        if cmd == Customers["Prefix"] + "themes":ClientMessage(to, txmenuThemes(Customers["Prefix"]))
                        if cmd.startswith("prefix"):
                            split = text.split(" ")
                            prefixx = split[1]
                            if prefixx in "$ ! ? # / , . -":
                                Customers["Prefix"] = prefixx
                                ClientMessageFlag(to, "Prefix set to ({})".format(prefixx))
                            else:
                                ClientMessage(to, "Use one of the followings:\n\n$ ! ? # / , . -")
                        if cmd == "clear prefix":
                            Customers["Prefix"] = ""
                            ClientMessageFlag(to, "Prefix cleared.")
                        if cmd == Customers["Prefix"] + "speed":
                            start = time.time()
                            time.sleep(0.006)
                            elapsed_time = time.time() - start
                            ClientMessageFlag(to, "%s" % str(round(elapsed_time, 5)))
                        if cmd == Customers["Prefix"] + "temps on":
                            if settings["fancy"] == True:
                                ClientMessageFlag(msg.to, "Templates are already enabled.")
                            elif settings["fancy"] == False:
                                settings["fancy"] = True
                                ClientMessageFlag(msg.to, "Templates are enabled.")
                        if cmd == Customers["Prefix"] + "temps off":
                            if settings["fancy"] == False:
                                ClientMessageFlag(msg.to, "Templates are already disabled.")
                            elif settings["fancy"]:
                                settings["fancy"] = False
                                ClientMessageFlag(msg.to, "Templates are disabled.")
                        if cmd == Customers["Prefix"] + "autoread on":
                            if settings["autoRead"] == True:
                                ClientMessageFlag(msg.to, "Autoread is already enabled.")
                            elif settings["autoRead"] == False:
                                settings["autoRead"] = True
                                ClientMessageFlag(msg.to, "Autoread is enabled.")
                        if cmd == Customers["Prefix"] + "autoread off":
                            if settings["autoRead"] == False:
                                ClientMessageFlag(msg.to, "Autoread is already disabled.")
                            elif settings["autoRead"]:
                                settings["autoRead"] = False
                                ClientMessageFlag(msg.to, "Autoread is disabled.")
                        if cmd == Customers["Prefix"] + "autoadd on":
                            if settings["autoAdd"] == True:
                                ClientMessageFlag(msg.to, "Autoadd is already enabled.")
                            elif settings["autoAdd"] == False:
                                settings["autoAdd"] = True
                                ClientMessageFlag(msg.to, "Autoadd is enabled.")
                        if cmd == Customers["Prefix"] + "autoadd off":
                            if settings["autoAdd"] == False:
                                ClientMessageFlag(msg.to, "Autoadd is already disabled.")
                            elif settings["autoAdd"]:
                                settings["autoAdd"] = False
                                ClientMessageFlag(msg.to, "Autoadd is disabled.")
                        if cmd.startswith(Customers["Prefix"] + "addmsg: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ", "")
                            settings["addMessageText"] = anu
                            ClientMessageFlag(msg.to, "Autoadd message is set to:\n" + settings["addMessageText"])
                        if cmd == Customers["Prefix"] + "autojoin on":
                            if settings["autoJoin"] == True:
                                ClientMessageFlag(msg.to, "Autojoin is already enabled.")
                            elif settings["autoJoin"] == False:
                                settings["autoJoin"] = True
                                ClientMessageFlag(msg.to, "Autojoin is enabled.")
                        if cmd == Customers["Prefix"] + "autojoin off":
                            if settings["autoJoin"] == False:
                                ClientMessageFlag(msg.to, "Autojoin is already disabled.")
                            elif settings["autoJoin"]:
                                settings["autoJoin"] = False
                                ClientMessageFlag(msg.to, "Autojoin is disabled.")
                        if cmd == Customers["Prefix"] + "join on":
                            if settings["joinMessage"] == True:
                                ClientMessageFlag(msg.to, "Join message is already enabled.")
                            elif settings["joinMessage"] == False:
                                settings["joinMessage"] = True
                                ClientMessageFlag(msg.to, "Join message is enabled.")
                        if cmd == Customers["Prefix"] + "join off":
                            if settings["joinMessage"] == False:
                                ClientMessageFlag(msg.to, "Join message is already disabled.")
                            elif settings["joinMessage"]:
                                settings["joinMessage"] = False
                                ClientMessageFlag(msg.to, "Join message is disabled.")
                        if cmd.startswith(Customers["Prefix"] + "joinmsg: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ", "")
                            settings["joinMessageText"] = anu
                            ClientMessageFlag(msg.to, "Join message is set to:\n" + settings["joinMessageText"])
                        if cmd == Customers["Prefix"] + "welcome on":
                            if settings["welcomeMessage"] == True:
                                ClientMessageFlag(msg.to, "Welcome message on join is already enabled.")
                            elif settings["welcomeMessage"] == False:
                                settings["welcomeMessage"] = True
                                ClientMessageFlag(msg.to, "Welcome message on joinis enabled.")
                        if cmd == Customers["Prefix"] + "welcome off":
                            if settings["welcomeMessage"] == False:
                                ClientMessageFlag(msg.to, "Welcome message on join is already disabled.")
                            elif settings["welcomeMessage"]:
                                settings["welcomeMessage"] = False
                                ClientMessageFlag(msg.to, "Welcome message on join is disabled.")
                        if cmd.startswith(Customers["Prefix"] + "welcomemsg: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ", "")
                            settings["welcomeMessageText"] = anu
                            ClientMessageFlag(msg.to, "Welcome message is set to:\n" + settings["welcomeMessageText"])
                        if cmd == Customers["Prefix"] + "leave on":
                            if settings["leaveMessage"] == True:
                                ClientMessageFlag(msg.to, "Leave message on join is already enabled.")
                            elif settings["leaveMessage"] == False:
                                settings["leaveMessage"] = True
                                ClientMessageFlag(msg.to, "Leave message on joinis enabled.")
                        if cmd == Customers["Prefix"] + "leave off":
                            if settings["leaveMessage"] == False:
                                ClientMessageFlag(msg.to, "Leave message on join is already disabled.")
                            elif settings["leaveMessage"]:
                                settings["leaveMessage"] = False
                                ClientMessageFlag(msg.to, "Leave message on join is disabled.")
                        if cmd.startswith(Customers["Prefix"] + "leavemsg: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ", "")
                            settings["leaveMessageText"] = anu
                            ClientMessageFlag(msg.to, "Leave message is set to:\n" + settings["leaveMessageText"])
                        if cmd == Customers["Prefix"] + "bye on":
                            if settings["byeMessage"] == True:
                                ClientMessageFlag(msg.to, "Bye message on join is already enabled.")
                            elif settings["byeMessage"] == False:
                                settings["byeMessage"] = True
                                ClientMessageFlag(msg.to, "Bye message on joinis enabled.")
                        if cmd == Customers["Prefix"] + "bye off":
                            if settings["byeMessage"] == False:
                                ClientMessageFlag(msg.to, "Bye message on join is already disabled.")
                            elif settings["byeMessage"]:
                                settings["byeMessage"] = False
                                ClientMessageFlag(msg.to, "Bye message on join is disabled.")
                        if cmd.startswith(Customers["Prefix"] + "byemsg: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ", "")
                            settings["byeMessageText"] = anu
                            ClientMessageFlag(msg.to, "Bye message is set to:\n" + settings["byeMessageText"])
                        if cmd == Customers["Prefix"] + "theme default":
                            Colors["Border"] = "#FFFFFF"
                            Colors["Font"] = "#FFFFFF"
                            Colors["Background"] = "#000000"
                            Colors["Template"] = "#13598b"
                            ClientMessageFlag(msg.to, "Default theme is active now")
                        if cmd == Customers["Prefix"] + "theme red":
                            Colors["Border"] = "#00CC00"
                            Colors["Font"] = "#00CC00"
                            Colors["Background"] = "#660000"
                            Colors["Template"] = "#708090"
                            ClientMessageFlag(msg.to, "Red theme is active now")
                        if cmd == Customers["Prefix"] + "theme pink":
                            Colors["Border"] = "#FFF8DC"
                            Colors["Font"] = "#FFF8DC"
                            Colors["Background"] = "#FF1493"
                            Colors["Template"] = "#708090"
                            ClientMessageFlag(msg.to, "Pink theme is active now")
                        if cmd == Customers["Prefix"] + "theme blue":
                            Colors["Border"] = "#00FFFF"
                            Colors["Font"] = "#00FFFF"
                            Colors["Background"] = "#000066"
                            Colors["Template"] = "#708090"
                            ClientMessageFlag(msg.to, "Blue theme is active now")
                        if cmd == Customers["Prefix"] + "theme cyan":
                            Colors["Border"] = "#66FFFF"
                            Colors["Font"] = "#66FFFF"
                            Colors["Background"] = "#006600"
                            Colors["Template"] = "#708090"
                            ClientMessageFlag(msg.to, "Cyan theme is active now")
                        if cmd == Customers["Prefix"] + "theme black":
                            Colors["Border"] = "#FFFFFF"
                            Colors["Font"] = "#FFFFFF"
                            Colors["Background"] = "#000000"
                            Colors["Template"] = "#708090"
                            ClientMessageFlag(msg.to, "Black theme is active now")
                        if cmd == Customers["Prefix"] + "theme white":
                            Colors["Border"] = "#000000"
                            Colors["Font"] = "#000000"
                            Colors["Background"] = "#FFFFFF"
                            Colors["Template"] = "#708090"
                            ClientMessageFlag(msg.to, "White theme is active now")
                        if cmd == Customers["Prefix"] + "theme yellow":
                            Colors["Border"] = "#660066"
                            Colors["Font"] = "#660066"
                            Colors["Background"] = "#FFFF00"
                            Colors["Template"] = "#708090"
                            ClientMessageFlag(msg.to, "Yellow theme is active now")
                        if cmd == Customers["Prefix"] + "theme purple":
                            Colors["Border"] = "#FFFF00"
                            Colors["Font"] = "#FFFF00"
                            Colors["Background"] = "#660066"
                            Colors["Template"] = "#708090"
                            ClientMessageFlag(msg.to, "Purple theme is active now")
                        if cmd == Customers["Prefix"] + "theme golden":
                            Colors["Border"] = "#000000"
                            Colors["Font"] = "#000000"
                            Colors["Background"] = "#DAA520"
                            Colors["Template"] = "#708090"
                            ClientMessageFlag(msg.to, "Golden theme is active now")
                        if cmd == Customers["Prefix"] + "theme green":
                            Colors["Border"] = "#CCFFCC"
                            Colors["Font"] = "#CCFFCC"
                            Colors["Background"] = "#006666"
                            Colors["Template"] = "#708090"
                            ClientMessageFlag(msg.to, "Green theme is active now")
                        if cmd.startswith(Customers["Prefix"] + "setid: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            Customer["makerLineid"] = "https://line.me/ti/p/~"+anu
                            ClientMessage(msg.to, "ID is set to:\n" +Customer["makerLineid"])
                        if cmd.startswith(Customers["Prefix"] + "clrfont: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            Colors["Font"] = anu
                            ClientMessage(msg.to, "Font color has been changed to:\n" + Colors["Template"])
                        if cmd.startswith(Customers["Prefix"] + "clrbg: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            Colors["Background"] = anu
                            ClientMessage(msg.to, "Background color has been changed to:\n" + Colors["Template"])
                        if cmd.startswith(Customers["Prefix"] + "clrtemp: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            Colors["Template"] = anu
                            ClientMessage(msg.to, "Template color has been changed to:\n" + Colors["Template"])
                        if cmd.startswith(Customers["Prefix"] + "set flag: "):
                            sep = msg.text.split(": ")
                            anu = msg.text.replace(sep[0] + ": ","")
                            Customer["userFlag"] = anu
                            ClientMessage(msg.to,"Flag name changed to " + Customer["userFlag"])
                        if cmd == Customers["Prefix"] + "color selection":
                            pub.sendMessage(msg.to, "Select the Colors from Website:\n\nhttps://www.colorhexa.com/")
#
                        if cmd.startswith(Customers["Prefix"] + "user "):
                            if len(Customers["myService"]) < Customers["limService"]:
                                proses = text.split(" ")
                                tx = text.replace(proses[0] + " ", "")
                                num = text.replace(proses[0] + " lcon", "")
                                if "lcon" == proses[1] or "lcon" + num == proses[1]:
                                    if "" == num:
                                        num = "1"
                                    l = int(num)
                                    l -= 1
                                    hasil = Lcontact(l)
                                    num = 0
                                    for user in hasil:
                                        if user not in Customers["myService"]:
                                            Customers["myService"].append(user)
                                            num += 1
                                    ClientMessage(to, "Added: {}".format(num))
                                else:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    if key == None:
                                        return
                                    else:
                                        key["MENTIONEES"][0]["M"]
                                        targets = []
                                        for x in key["MENTIONEES"]:
                                            targets.append(x["M"])
                                        num = 0
                                        for user in targets:
                                            if user not in Customers["myService"]:
                                                Customers["myService"].append(user)
                                                num += 1
                                        ClientMessage(to, "Added: {}".format(num))
                            else:
                                ClientMessage(to, "Maximum number of Users: {}".format(len(Customers["LimBuyers"])))
                        if cmd == Customers["Prefix"] + "users":
                            if Customers["myService"] == []:
                                ClientMessage(to, "Users List is Empty!")
                            else:
                                text = "𝗨𝗦𝗘𝗥𝗦\n\n"
                                num = 0
                                for user in Customers["myService"]:
                                    try:
                                        num += 1
                                        text += str(num) + " {}\n".format(pub.getContact(user).displayName)
                                    except:
                                        Customers["myService"].remove(user)
                                        num -= 1
                                        os.system('rm -rf {}'.format(str(user)))
                                        os.system("screen -S {} -X quit".format(str(user)))
                                text += "\nTOTAL: {} users".format(str(len(Customers["myService"])))
                                ClientMessage(to, text)
                        if cmd == Customers["Prefix"] + "contact users":
                            if Customers["myService"] == []:
                                ClientMessage(to, "Users List is Empty!")
                            else:
                                for a in Customers["myService"]:
                                    pub.sendContact(to, a)
                        if cmd.startswith(Customers["Prefix"] + "broadcast: "):
                            tod = text.split(" ")
                            hey = text.replace(tod[0] + " ", "")
                            text = "{}".format(hey)
                            groups = pub.getGroupIdsJoined()
                            friends = pub.getAllContactIds()
                            for gr in groups:
                                ClientMessage(to, "Broadcast send to: {} Groups".format(str(len(groups))))
# Add 20 Option
                        if cmd == Customers["Prefix"] + "groups":
                            if settings["fancy"] == True:
                                gid = pub.getGroupIdsJoined()
                                sd = pub.getGroups(gid)
                                ret = ""
                                no = 0
                                total = len(gid)
                                for G in sd:
                                    member = len(G.members)
                                    no += 1
                                    ret += "\n{}. {} {}".format(no, G.name[0:45], member)
                                #ret += cd
                                k = len(ret) // 10000
                                for aa in range(k + 1):
                                    ClientMessage(msg.to, "𝗚𝗥𝗢𝗨𝗣𝗦\n"+"{}".format(ret[aa * 10000: (aa + 1) * 10000]))
                            else:
                                groups = [gid for gid in pub.getGroupIdsJoined()]
                                listWithTextGid(to, "𝗚𝗥𝗢𝗨𝗣𝗦", "group", groups)
                        if cmd.startswith(Customers["Prefix"] + "members"):
                            if settings["fancy"] == True:
                                split = text.split(" ")
                                number = text.replace(split[0] + " ", "")
                                groups = pub.getGroupIdsJoined()
                                try:
                                    try:
                                        group = groups[int(number) - 1]
                                        G = pub.getGroup(group)
                                        jembut = [contact.mid for contact in G.members]
                                        for mid in jembut:
                                            tx = "𝗠𝗘𝗠𝗕𝗘𝗥𝗦 𝗼𝗳:\n" + pub.getGroup(group).name + "\n\n"
                                            num += 1
                                            tx += "{}. {}\n".format(num, pub.getContact(a).displayName)
                                        ClientMessage(to, tx)
                                    except:
                                        group = to
                                        G = pub.getGroup(group)
                                        jembut = [contact.mid for contact in G.members]
                                        for mid in jembut:
                                            tx = "𝗠𝗘𝗠𝗕𝗘𝗥𝗦 𝗼𝗳:\n" + pub.getGroup(group).name + "\n\n"
                                            num += 1
                                            tx += "{}. {}\n".format(num, pub.getContact(a).displayName)
                                        ClientMessage(to, tx)
                                except Exception as e:
                                    print(e)
                            else:
                                split = text.split(" ")
                                number = text.replace(split[0] + " ", "")
                                groups = pub.getGroupIdsJoined()
                                try:
                                    try:
                                        group = groups[int(number) - 1]
                                        G = pub.getGroup(group)
                                        jembut = [contact.mid for contact in G.members]
                                        tx = "𝗠𝗘𝗠𝗕𝗘𝗥𝗦 𝗼𝗳:\n" + pub.getGroup(group).name
                                        list20usersWithHeading(to, tx, "invitees", jembut)
                                    except:
                                        group = to
                                        G = pub.getGroup(group)
                                        jembut = [contact.mid for contact in G.members]
                                        tx = "𝗠𝗘𝗠𝗕𝗘𝗥𝗦 𝗼𝗳:\n" + pub.getGroup(group).name
                                        list20usersWithHeading(to, tx, "invitees", jembut)
                                except Exception as e:
                                    print(e)
                        if cmd.startswith(Customers["Prefix"] + "cmembers"):
                            split = text.split(" ")
                            number = text.replace(split[0] + " ", "")
                            groups = pub.getGroupIdsJoined()
                            try:
                                group = groups[int(number) - 1]
                                G = pub.getGroup(group)
                                jembut = [contact.mid for contact in G.members]
                                tx = "𝗠𝗘𝗠𝗕𝗘𝗥𝗦 𝗼𝗳:\n" + pub.getGroup(group).name + "\n\n"
                                ClientMessage(to, tx)
                                num = 1
                                for mid in jembut:
                                    pub.sendContact(to, mid)
                                    num += 1
                                tx3 = "Total {} members.".format(str(len(jembut)))
                                ClientMessage(to, tx3)
                            except:
                                group = to
                                G = pub.getGroup(group)
                                jembut = [contact.mid for contact in G.members]
                                tx = "𝗠𝗘𝗠𝗕𝗘𝗥𝗦 𝗼𝗳:\n" + pub.getGroup(group).name + "\n\n"
                                ClientMessage(to, tx)
                                num = 1
                                for mid in jembut:
                                    pub.sendContact(to, mid)
                                    num += 1
                                tx3 = "Total {} members.".format(str(len(jembut)))
                                ClientMessage(to, tx3)
                        if cmd.startswith(Customers["Prefix"] + "pendings"):
                            split = text.split(" ")
                            number = text.replace(split[0] + " ", "")
                            groups = pub.getGroupIdsJoined()
                            try:
                                try:
                                    group = groups[int(number) - 1]
                                    G = pub.getGroup(group)
                                    jembut = [contact.mid for contact in G.invitee]
                                    tx = "𝗣𝗘𝗡𝗗𝗜𝗡𝗚𝗦 𝗼𝗳:\n" + pub.getGroup(group).name
                                    list20usersWithHeading(to, tx, "invitees", jembut)
                                except:
                                    group = to
                                    G = pub.getGroup(group)
                                    jembut = [contact.mid for contact in G.invitee]
                                    tx = "𝗣𝗘𝗡𝗗𝗜𝗡𝗚𝗦 𝗼𝗳:\n" + pub.getGroup(group).name
                                    list20usersWithHeading(to, tx, "invitees", jembut)
                            except:
                                ClientMessage(to, "No pending Invites.")
                        if cmd.startswith(Customers["Prefix"] + "cpendings"):
                            split = text.split(" ")
                            number = text.replace(split[0] + " ", "")
                            groups = pub.getGroupIdsJoined()
                            try:
                                try:
                                    group = groups[int(number) - 1]
                                    G = pub.getGroup(group)
                                    jembut = [contact.mid for contact in G.invitee]
                                    tx = "𝗣𝗘𝗡𝗗𝗜𝗡𝗚𝗦 𝗼𝗳:\n" + pub.getGroup(group).name + "\n\n"
                                    ClientMessage(to, tx)
                                    num = 1
                                    for mid in jembut:
                                        pub.sendContact(to, mid)
                                        num += 1
                                    tx3 = "Total {} pendings.".format(str(len(jembut)))
                                    ClientMessage(to, tx3)
                                except:
                                    group = to
                                    G = pub.getGroup(group)
                                    jembut = [contact.mid for contact in G.invitee]
                                    tx = "𝗣𝗘𝗡𝗗𝗜𝗡𝗚𝗦 𝗼𝗳:\n\n" + pub.getGroup(group).name + "\n\n"
                                    ClientMessage(to, tx)
                                    num = 1
                                    for mid in jembut:
                                        pub.sendContact(to, mid)
                                        num += 1
                                    tx3 = "Total {} pendings.".format(str(len(jembut)))
                                    ClientMessage(to, tx3)
                            except:
                                ClientMessage(to, "No pending Invites.")
                        if cmd.startswith(Customers["Prefix"] + "leave"):
                            split = text.split(" ")
                            number = text.replace(split[0] + " ", "")
                            groups = pub.getGroupIdsJoined()
                            try:
                                group = groups[int(split[1]) - 1]
                                ClientMessage(group, settings["byeMessageText"])
                                pub.leaveGroup(group)
                                ClientMessage(to, "Successfully left ["+pub.getGroup(group).name+"]")
                            except:
                                group = to
                                ClientMessage(group, Settings["byeMessageText"])
                                pub.leaveGroup(group)
                        if cmd.startswith(Customers["Prefix"] + "bye"):
                            ClientMessage(to, Settings["byeMessageText"])
                            pub.leaveGroup(to)
                        if cmd.startswith(Customers["Prefix"] + "ourl"):
                            split = text.split(" ")
                            number = text.replace(split[0] + " ", "")
                            groups = pub.getGroupIdsJoined()
                            try:
                                gc = groups[int(split[1]) - 1]
                                group = pub.getGroup(gc)
                                group.preventedJoinByTicket = False
                                pub.updateGroup(group)
                                gurl = pub.reissueGroupTicket(gc)
                                ClientMessage(to, "Group URL for:\n"+ group.name + "\n" + "https://line.me/R/ti/g/" + gurl)
                            except:
                                gc = to
                                group = pub.getGroup(gc)
                                group.preventedJoinByTicket = False
                                pub.updateGroup(group)
                                gurl = pub.reissueGroupTicket(gc)
                                ClientMessage(to, "Group URL:\n" + "https://line.me/R/ti/g/" + gurl)
                        if cmd.startswith(Customers["Prefix"] + "curl"):
                            split = text.split(" ")
                            number = text.replace(split[0] + " ", "")
                            groups = pub.getGroupIdsJoined()
                            try:
                                gc = groups[int(split[1]) - 1]
                                group = pub.getGroup(gc)
                                group.preventedJoinByTicket = True
                                pub.updateGroup(group)
                                ClientMessage(to, "Group URL closed for:\n"+ group.name)
                            except:
                                gc = to
                                group = pub.getGroup(gc)
                                group.preventedJoinByTicket = True
                                pub.updateGroup(group)
                                ClientMessage(to, "Group URL closed")
                        if cmd.startswith(Customers["Prefix"] + "ginfo "):
                            number = removeCmd("ginfo",text)
                            groups = pub.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = pub.getGroup(group)
                                path = "https://obs.line-scdn.net/" + G.pictureStatus
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Group Creator"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Closed"
                                    gTicket = "QR Closed"
                                else:
                                    gQr = "Open"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(pub.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "𝗚𝗥𝗢𝗨𝗣 𝗜𝗡𝗙𝗢\n"
                                ret_ += "\nGroup  Name  : {}".format(G.name)
                                ret_ += "\nGroup Id     : {}".format(G.id)
                                ret_ += "\nGroup Creator: {}".format(gCreator)
                                ret_ += "\nGroup Created: {}".format(str(timeCreated))
                                ret_ += "\nMembers      : {}".format(str(len(G.members)))
                                ret_ += "\nPendings     : {}".format(gPending)
                                ret_ += "\nStatus       : {}".format(gQr)
                                ret_ += "\nGroup QR     : {}".format(gTicket)
                                pub.sendImageWithURL(to, path)
                                ClientMessage(msg.to, str(ret_))
                                pub.sendContact(to, G.creator.mid)
                            except:
                                pass
                        if cmd.startswith(Customers["Prefix"] + "groupcast"):
                            rah = text.split(" ")
                            matt = text.replace(rah[0] + " ", "")
                            chat = "{}".format(matt)
                            groups = pub.getGroupIdsJoined()
                            for gr in groups:
                                groupscast(gr, matt)
                                time.sleep(2)
                            ClientMessage(msg.to, "Broadcast sent to {} groups.".format(str(len(groups))))
                        if cmd == Customers["Prefix"] + "reboot":
                            ClientMessage(to, "Rebooting ...")
                            settings["restartPoint"] = to
                            restartBot()
#=========== PROFILE COMMMANDS ==============
                        if cmd.startswith(Customers["Prefix"] + "upname "):
                            string = removeCmd("upname", text)
                            if len(string) <= 10000000000:
                                pname = pub.getContact(pubMID).displayName
                                profile = pub.getProfile()
                                profile.displayName = string
                                pub.updateProfile(profile)
                                ClientMessage(to, "Updated Name From: "+str(pname)+"\nTo :"+str(string))
                        if cmd.startswith(Customers["Prefix"] + "upbio "):
                            string = removeCmd("upbio", text)
                            if len(string) <= 10000000000:
                                pname = pub.getContact(pubMID).statusMessage
                                profile = pub.getProfile()
                                profile.statusMessage = string
                                pub.updateProfile(profile)
                                ClientMessage(msg.to,"Profile status updated from:\n"+str(pname)+"\nto:"+str(string))
                        if cmd == Customers["Prefix"] + "upimage":
                            settings["changePicture"] = True
                            ClientMessage(msg.to, "Please send an image ...")
                        if cmd.startswith(Customers["Prefix"] + "addme "):
                            if msg._from not in Customers['myService']:
                                nama = str(text.split(' ')[1])
                                Customers['myService'].append(msg._from)
                                pub.sendMention(msg.to, "Added @! to Login List.","",[msg._from])
                            else:
                                pub.sendMention(msg.to, "Owner @! already in Login List.","",[msg._from])
#==========================================
# USER AND BUYER AND MAKER COMMANDS
#==========================================
                    if sender in maker or sender in Customers["myService"] or sender in Customers["Buyers"]:
                        if cmd == "ping":
                            ClientMessage(to, "pong")
                        if cmd == ".here":
                            ClientMessage(to, "20/20 bots in group.")
                    if sender in Customers["myService"] and sender not in Customers["Buyers"]:
                        if cmd == Customers["Prefix"] + "help":
                            ClientMessage(to, txmenuUser(Customers["Prefix"]))
                    if sender in Customers["myService"]:
#==========================================
                        if cmd == Customers["Prefix"] + "liff":
                            pub.generateReplyMessage(msg.id)
                            pub.sendReplyMessage(msg.id, to, "Allow the following link for Templates:\n\nline://app/1602687308-GXq4Vvk9")
                        if cmd == Customers["Prefix"] + "relogin":
                            if msg._from in Customers["myService"]:
                                try:
                                    with open("{}/token1.txt".format(msg._from), "r") as file:
                                        tlist = file.readlines()
                                        x = [x.strip() for x in tlist]
                                    asis = []
                                    for t in range(len(x)):
                                        if t != 0:
                                            asis.append(x[t])
                                    with open("{}/token1.txt".format(msg._from), "r") as file:
                                        tlist = file.readlines()
                                    isi = loginv2(pub,to,msg._from)
                                    os.system('cd {} && echo -n "{}" > token1.txt'.format(msg._from, isi))
                                    if asis != []:
                                        for m in asis:
                                            with open("{}/token1.txt".format(msg._from), 'a') as f:
                                                f.write("\n{}".format(m))
                                    os.system("rm -rf {}/linepy && cp -r sbtemp/linepy {}/linepy".format(msg._from, msg._from ))
                                    os.system("cp -r sbtemp/login.py {}/login.py".format(msg._from))
                                    os.system("screen -S {} -X quit".format(msg._from))
                                    os.system('screen -dmS {}'.format(msg._from))
                                    os.system('screen -r {} -X stuff "cd {} && python3 login.py \n"'.format(msg._from, msg._from))
                                    pub.sendMessage(to, "Login Successful.\ntap this link before you use bot line://app/1602687308-GXq4Vvk9")
                                except:
                                    ClientMessage(to, "Please Login first")
                        if cmd == Customers["Prefix"] + "login":
                            if msg._from in Customers["myService"]:
                                user = msg._from
                                cek = detectUser(to,msg._from)
                                if cek != True:return
                                try:
                                    if msg._from in Customers['listLogin']:
                                        with open("{}/token1.txt".format(msg._from), "r") as file:
                                            tlist = file.readlines()
                                            x = [x.strip() for x in tlist]
                                        asis = []
                                        for t in range(len(x)):
                                            if t != 0:
                                                asis.append(x[t])
                                        with open("{}/token1.txt".format(msg._from), "r") as file:
                                            tlist = file.readlines()
                                        isi = loginv2(pub,to,msg._from)
                                        os.system('cd {} && echo -n "{}" > token1.txt'.format(msg._from, isi))
                                        if asis != []:
                                            for m in asis:
                                                with open("{}/token1.txt".format(msg._from), 'a') as f:
                                                    f.write("\n{}".format(m))
                                        os.system("cp -r sbtemp/login.py {}/login.py".format(msg._from))
                                        os.system("screen -S {} -X quit".format(msg._from))
                                        os.system('screen -dmS {}'.format(msg._from))
                                        os.system('screen -r {} -X stuff "cd {} && python3 login.py \n"'.format(msg._from, msg._from))
                                        pub.sendMessage(to, "Login Successful.\ntap this link before you use bot line://app/1602687308-GXq4Vvk9")
                                    else:
                                        isi = loginv2(pub,to,user)
                                        os.system('cp -r sbtemp {}'.format(msg._from))
                                        os.system('cd {} && echo -n "{}" > token1.txt'.format(msg._from, isi))
                                        os.system("screen -S {} -X quit".format(msg._from))
                                        os.system('screen -dmS {}'.format(msg._from))
                                        os.system('screen -r {} -X stuff "cd {} && python3 login.py \n"'.format(msg._from, msg._from))
                                        Customers['listLogin'].append(user)
                                        backupData()
                                    time.sleep(5)
                                    ClientMessageFlag(to, "Login Successful.")
                                except Exception as e:pub.sendMention(msg.to, '@!\n'+str(e),' ', [msg._from])
                        if cmd == Customers["Prefix"] + "logout":
                            if msg._from in Customers['listLogin']:
                                if msg._from in Customers["myService"] or msg._from in maker:
                                    user = msg._from
                                    os.system("screen -S {} -X quit".format(str(user)))
                                    time.sleep(2)
                                    pub.sendMention(msg.to, '@!\nLogout Successful.',' ', [msg._from])
                            else:
                                if msg._from in Customers["myService"] or msg._from in maker:
                                    user = msg._from
                                    os.system("screen -S {} -X quit".format(str(user)))
                                    time.sleep(2)
                                    pub.sendMention(msg.to, '@!\nLogout Successful.',' ', [msg._from])
#===========================================================
                if msg.contentType == 1:
                    if settings["changePicture"] == True:
                        path = pub.downloadObjectMsg(msg_id, saveAs="tmp/pict.bin")
                        settings["changePicture"] = False
                        pub.updateProfilePicture(path)
                        ClientMessage(msg.to, "Profile picture changed.")
#===========================================================
# Lurk
        if op.type == 55:
            if op.param1 in settings["lurkRoom"] and op.param2 not in settings["lurkRoom"][op.param1]:
                settings["lurkRoom"][op.param1].append(op.param2)
                contact = pub.getContact(op.param2)
                ClientMessage(op.param1, settings["lurkMessage"] + " {}".format(str(contact.displayName)))
                time.sleep(1)
# Lurk Tag
# Sider
        if op.type == 55:
            if op.param1 in settings["siderRoom"] and op.param2 not in settings["siderRoom"][op.param1]:
                settings["siderRoom"][op.param1].append(op.param2)
                fit = pub.getCompactGroup(op.param1)
                pubName = "{}".format(str(pub.getContact(pubMID).displayName))
                pubPP = "https://obs.line-scdn.net/{}".format(pub.getContact(pubMID).pictureStatus)
                pubCV = "https://obs.line-scdn.net/{}".format(pub.getContact(pubMID).pictureStatus)
                memmberName = "{}".format(str(pub.getContact(op.param2).displayName))
                memmberPP = "https://obs.line-scdn.net/{}".format(pub.getContact(op.param2).pictureStatus)
                memmberCV = "https://obs.line-scdn.net/{}".format(pub.getProfileCoverURL(op.param2))
                Message = settings["siderMessage"]
                TSider1(op.param1, memmberPP, memmberName, Message)
                time.sleep(1)
        backupData()
    except Exception as error:
        logError(error)
        traceback.print_tb(error.__traceback__)
userList = {}
def loginv2(pub,to,sender):
  from linepy.QRV2 import LineAuth
  try:
    userList[sender] = {}
    userList[sender]["currentProcess"] = LineAuth(Helper=pub, Groups=to)
    userList[sender]["startProcess"] = time.time()
    tokens = userList[sender]["currentProcess"].generateAuthToken(sender)
    if tokens is not None:
       return tokens
    else:ClientMessage(to, "QRCode Expired")
  except Exception:print(traceback.format_exc())
#========================================
def getLink(to, user, cert):
    apiKey = "U9FE38KWtAJb"
    headers = {
        "apiKey": apiKey,  ## APIKEY, YOU CAN BUY FROM ME IN WHATSAPP: +6289625658302
        "appName": "IOSIPAD\t10.14.0\tiPhone XS\t13.5.1",
        "cert": cert,  ## IF YOU WANT LOGIN WITH CERT
        "server": random.choice(["pool-1", "pool-2"]),  ## IP POOL SELECTION: pool-1 / pool-2 / vip(COMING SOON)
        "sysname": "BE-Team"  ## SYSTEM NAME, YOU CAN CUSTOMIZE IT
    }
    main = json.loads(requests.get("https://api.be-team.me/qrv2", headers=headers).text)
    pub.sendMessage(to, "QR Link: {}\nLogin IP: {}".format(main["result"]["qr_link"], main["result"]["login_ip"]))
    if not headers["cert"]:
        pub.sendMessage(to, "Callback Pincode: " + main["result"]["cb_pincode"])
        result = json.loads(requests.get(main["result"]["cb_pincode"], headers=headers).text)
        pub.sendMessage(to, "Your Pincode: " + result["result"])
    result = json.loads(requests.get(main["result"]["cb_token"], headers=headers).text)
    if result["status"] != 200:

        return
    else:
        return result["result"]["cert"], result["result"]["token"]
#####GET TOKEN FROM LRTT
API_URL = "https://api.lrtt.icu/secondaryQrCodeLogin.do"
HEADERS = {
        "ios_ipad": {
            "User-Agent": "Line/10.17.2",
            "X-Line-Application": "IOSIPAD  10.14.0 iPhone XS   13.5.1s"
        }
    }
def getResult(data,cert=True):
    if cert == True:
        return data["token"]
    else:
        return (data["token"], data["certificate"])
def inputToken(grup,user, header, certificate="", callback=lambda output: print(output)):
    assert header in HEADERS, "invaild header"
    resp = requests.post(API_URL + "/login?" + urllib.parse.urlencode({"custom_headers": HEADERS[header], "certificate": certificate}))
    res = resp.json()
    if resp.status_code != 200:
        pesantag(grup,user,"Link Login Expired..")
        Exception(res)
    pesantag(grup,user,"\nLogin URL: %s" % (res["url"]))
    while "token" not in res:
        resp = requests.post(API_URL + res["callback"])
        res = resp.json()
        if resp.status_code != 200:
            pesantag(grup,user,"Input code failed..")
        if "pin" in res:
            pesantag(grup,user,"\nInput PIN: %s" % (res["pin"]))
    if certificate == "":return getResult(res,False)
    return getResult(res,True)
def getTokenFromLRTT(grup,user):
    headers = "ios_ipad"
    if user in Customers['listLogin']:
        if "None" == Customers['listLogin'][user]:
            token, cert = inputToken(grup,user,headers)
            print(cert)
            return cert,token
        token = inputToken(grup,user,headers,Customers['listLogin'][user])
        return None,token
    else:
        token, cert = inputToken(grup,user,headers)
        return cert,token
def pesantag(to, mid,texnya):
    try:
        aa = '{"S":"0","E":"3","M":'+json.dumps(mid)+'}'
        text_ = '@x '+texnya
        pub.sendMessage(to, text_, contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
    except Exception as error:
        logError(error)
def detectUser(to,user):
    try:
        with open("{}/token1.txt".format(user), "r") as file:
            tlist = file.readlines()
        os.system("screen -S {} -X quit".format(user))
        os.system('screen -dmS {}'.format(user))
        os.system('screen -r {} -X stuff "cd {} && python3 login.py \n"'.format(user, user))
        pub.sendMessage(to, "Your previous token still exists, and if selfbot is not active, type ,relogin")
        return False
    except: return True
def list20usersWithHeading(to,text1,text2,jembut):
    num = 0
    tot = {}
    for mid in jembut:
        tot[mid] = True
        if 20 == len(tot):
            tx = "{}\n\n".format(text1)
            for a in tot:
                num += 1
                tx += "{}. {}\n".format(num, pub.getContact(a).displayName)
            tot = {}
            pub.sendMessage(to,tx)
    jem = "{}\n\n".format(text1)
    for a in tot:
        num += 1
        jem += "{}. {}\n".format(num, pub.getContact(a).displayName)
    return pub.sendMessage(to, jem+"\nTotal {}: {}".format(text2,len(jembut)))
def listWithTextGid(to,text1,text2,jembut):
    num = 0
    tot = {}
    for mid in jembut:
        tot[mid] = True
        if 20 == len(tot):
            tx = "{}\n".format(text1)
            for a in tot:
                num += 1
                tx += "{}. {}\n".format(num, pub.getGroup(a).name)
            tot = {}
            pub.sendMessage(to,tx)
    jem = "{}\n".format(text1)
    for a in tot:
        num += 1
        jem += "{}. {}\n".format(num, pub.getGroup(a).name)
    return pub.sendMessage(to, jem+"Total {}: {}".format(text2,len(jembut)))
def runbot():
    while True:
        try:
            ops = pubPoll.singleTrace(count=50)
            if ops != None:
                for op in ops:
                   loop.run_until_complete(helprBot(op))
                   pubPoll.setRevision(op.revision)
        except Exception as e:
            logError(e)
if __name__ == "__main__":
    runbot()
    app.run()
